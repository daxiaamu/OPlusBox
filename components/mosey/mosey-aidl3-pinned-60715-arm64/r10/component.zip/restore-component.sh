#!/system/bin/sh
# Module-owned installation source; Android owns the runnable APK installation.
set -eu
MODDIR=${0%/*}
sha256sum -c "$MODDIR/mounted-checksums.txt" || exit 1
setprop sys.obx.mosey_pin 60715-v1
expected=$(cat "$MODDIR/apk-sha256.txt")
package_paths() { pm path --user 0 com.google.android.mosey 2>/dev/null || true; }
package_hashes() {
    printf '%s\n' "$1" | while IFS= read -r entry; do
        case "$entry" in
            package:*) sha256sum "${entry#package:}" || exit 1 ;;
            *) exit 1 ;;
        esac
    done | cut -d ' ' -f 1 | sort
}
normal_install() {
    [ -n "$1" ] || return 1
    printf '%s\n' "$1" | while IFS= read -r entry; do
        case "$entry" in package:/data/app/*) ;; *) exit 1 ;; esac
    done
}
paths=$(package_paths)
actual=$(package_hashes "$paths")
if normal_install "$paths" && [ "$actual" = "$expected" ]; then
    setprop sys.obx.mosey_backend_ready local-v1
    exit 0
fi
if [ "$actual" != "$expected" ]; then
    case "$paths" in
        *package:/data/app/*)
            # User-authorized rollback of this component only. ColorOS can return
            # a nonzero status on success, so verify the final installed bytes.
            pm uninstall-system-updates com.google.android.mosey || true
            ;;
    esac
fi
# A normal official install keeps resources/split libraries visible when a ROOT
# provider hides module mounts. Do not change any app's hiding or ROOT profile.
total=0
while IFS= read -r name; do
    total=$((total + $(stat -c %s "/system_ext/priv-app/MoseyApp/$name")))
done < "$MODDIR/apk-files.list"
created=$(pm install-create --user 0 -r -S "$total")
session=${created##*[}
session=${session%]*}
case "$session" in ''|*[!0-9]*) printf '%s\n' "$created"; exit 1 ;; esac
cleanup() { pm install-abandon "$session" >/dev/null 2>&1 || true; }
trap cleanup EXIT
while IFS= read -r name; do
    source="/system_ext/priv-app/MoseyApp/$name"
    pm install-write -S "$(stat -c %s "$source")" "$session" "$name" "$source"
done < "$MODDIR/apk-files.list"
pm install-commit "$session"
trap - EXIT
paths=$(package_paths)
normal_install "$paths" || exit 1
[ "$(package_hashes "$paths")" = "$expected" ] || exit 1
setprop sys.obx.mosey_backend_ready local-v1
