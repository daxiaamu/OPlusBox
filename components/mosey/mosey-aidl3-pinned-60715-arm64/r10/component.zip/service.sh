#!/system/bin/sh
# One startup verification and targeted update rollback; no polling daemon.
set -eu
MODDIR=${0%/*}
setprop sys.obx.mosey_backend_ready failed
# Keep the user's persistent update protection across boot. A blank volatile
# session still denies all radio hooks until the app revalidates the backend.
setprop sys.obx.mosey_session ''
sha256sum -c "$MODDIR/mounted-checksums.txt" || exit 1
setprop sys.obx.mosey_pin 60715-v1

# PackageManager may still be starting when late_start services run.
paths=''
attempt=0
while [ "$attempt" -lt 30 ]; do
    paths=$(pm path --user 0 com.google.android.mosey 2>/dev/null || true)
    [ -n "$paths" ] && break
    attempt=$((attempt + 1))
    sleep 1
done
[ -n "$paths" ] || exit 1
# Restore at this startup boundary only, not with a background update-removal loop.
"$MODDIR/restore-component.sh"
