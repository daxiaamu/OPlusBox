#!/system/bin/sh
MODDIR=${0%/*}
setprop persist.sys.obx.mosey_allow 0
setprop sys.obx.mosey_session ''
setprop sys.obx.mosey_pin ''
"$MODDIR/controller" stop
