#!/system/bin/sh
MODDIR=${0%/*}
# Protection must exist before background installers can start, even with sharing off.
setprop sys.obx.mosey_pin 60715-v1
. "$MODDIR/coloros-google-features.sh"
