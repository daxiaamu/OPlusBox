#!/system/bin/sh
# This script is sourced by the installer; do not change its global shell options.
[ "$(getprop ro.product.model)" = PLK110 ] || abort 'Wrong model'
[ "$(getprop ro.build.display.id)" = 'PLK110_17.0.0.105(CN01)' ] || abort 'Build changed; regenerate snapshots'
DEST=/metadata/obx_mosey_declarations_20261025
sha256sum -c "$MODPATH/stock-checksums.txt" || abort 'Stock declarations changed'
# Reject added stock files too: a directory snapshot must never hide newer fragments.
COUNT=$(find /system_ext/etc/vintf/manifest -type f | wc -l)
[ "$COUNT" -eq 6 ] || { [ "$COUNT" -eq 7 ] && [ "$(sha256sum /system_ext/etc/vintf/manifest/manifest_mosey.xml | cut -d ' ' -f 1)" = 64d186e23527c993c1ba2dd973128ca3834e8649e51d28d9a197fc663255d50f ]; } || abort 'Directory contents changed'
COUNT=$(find /system_ext/etc/permissions -type f | wc -l)
[ "$COUNT" -eq 74 ] || { [ "$COUNT" -eq 75 ] && [ "$(sha256sum /system_ext/etc/permissions/privapp-permissions-com.google.android.mosey.xml | cut -d ' ' -f 1)" = 80dcb7b3d55438547a96de787d797b6f7674a6aa42126c4d2e6cd413d3e93294 ]; } || abort 'Directory contents changed'
COUNT=$(find /system/etc/default-permissions -type f | wc -l)
[ "$COUNT" -eq 2 ] || { [ "$COUNT" -eq 3 ] && [ "$(sha256sum /system/etc/default-permissions/default-permissions-com.google.android.mosey.xml | cut -d ' ' -f 1)" = 19d7d6461a3aeb1348b5a3b8d54f02c7f6244e761b7790c4aa60cc95822b608c ]; } || abort 'Directory contents changed'
if [ -e "$DEST" ]; then
    [ -d "$DEST" ] && [ ! -L "$DEST" ] || abort 'Unexpected metadata destination'
    [ "$(find "$DEST" -type l | wc -l)" -eq 0 ] || abort 'Unexpected metadata symlink'
    sha256sum -c "$MODPATH/payload-checksums.txt" || abort 'Existing metadata differs; refusing replacement'
[ "$(find "$DEST" -type f | wc -l)" -eq 85 ] || abort 'Unexpected metadata files'
else
    mkdir -p "$DEST" || abort 'Metadata mkdir failed'
    cp -a "$MODPATH/payload/." "$DEST/" || abort 'Metadata copy failed'
fi
chown -R 0:0 "$DEST" || abort 'Metadata ownership failed'
find "$DEST" -type d -exec chmod 0755 {} \; || abort 'Directory modes failed'
find "$DEST" -type f -exec chmod 0644 {} \; || abort 'File modes failed'
chcon -R u:object_r:system_file:s0 "$DEST" || abort 'Metadata labels failed'
sha256sum -c "$MODPATH/payload-checksums.txt" || abort 'Metadata payload verification failed'
ui_print 'Declarations only: no APK/server/service/start commands'

NATIVE=/metadata/obx_mosey_native_20261025
if [ -e "$NATIVE" ]; then
    [ -d "$NATIVE" ] && [ ! -L "$NATIVE" ] || abort 'Unexpected native destination'
    [ "$(find "$NATIVE" -type f | wc -l)" -eq 2 ] || abort 'Unexpected native files'
    [ "$(find "$NATIVE" -type l | wc -l)" -eq 0 ] || abort 'Unexpected native symlink'
    sha256sum -c "$MODPATH/native-checksums.txt" || abort 'Native files differ'
else
    mkdir -p "$NATIVE" || abort 'Native mkdir failed'
    cp -a "$MODPATH/native/." "$NATIVE/" || abort 'Native copy failed'
fi
chown -R 0:0 "$NATIVE" || abort 'Native ownership failed'
find "$NATIVE" -type d -exec chmod 0755 {} \; || abort 'Native directory modes failed'
chmod 0755 "$NATIVE/bin/mosey_server" || abort 'Server mode failed'
chmod 0644 "$NATIVE/lib64/libmosey_daemon_ffi.so" || abort 'Library mode failed'
chcon -R u:object_r:system_file:s0 "$NATIVE" || abort 'Native labels failed'
chcon u:object_r:mosey_server_exec:s0 "$NATIVE/bin/mosey_server" || abort 'Server label failed'
sha256sum -c "$MODPATH/native-checksums.txt" || abort 'Native digest failed'
ui_print 'Official native backend staged disabled/oneshot; no APK or auto-start trigger'

APP=/metadata/obx_mosey_app_20261025
if [ -e "$APP" ]; then
    [ -d "$APP" ] && [ ! -L "$APP" ] || abort 'Unexpected app destination'
    [ "$(find "$APP" -type f | wc -l)" -eq 1 ] || abort 'Unexpected app files'
    [ "$(find "$APP" -type l | wc -l)" -eq 0 ] || abort 'Unexpected app symlink'
    sha256sum -c "$MODPATH/app-checksums.txt" || abort 'Existing app digest differs'
else
    mkdir -p "$APP" || abort 'App mkdir failed'
    cp -a "$MODPATH/app/." "$APP/" || abort 'App copy failed'
fi
chown -R 0:0 "$APP" || abort 'App ownership failed'
find "$APP" -type d -exec chmod 0755 {} \; || abort 'App directories failed'
find "$APP" -type f -exec chmod 0644 {} \; || abort 'App modes failed'
chcon -R u:object_r:system_file:s0 "$APP" || abort 'App label failed'
sha256sum -c "$MODPATH/app-checksums.txt" || abort 'App digest failed'
ui_print 'Official privileged APK added. Keep LSPosed research bind guard active before reboot.'
