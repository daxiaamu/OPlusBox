#!/system/bin/sh
[ "$(getprop ro.build.version.sdk)" -ge 36 ] || abort 'Android 16 or newer required'
getprop ro.product.cpu.abilist | grep -q arm64-v8a || abort 'ARM64 required'
for type in mosey_app mosey_server mosey_server_exec; do
  grep -aq "$type" /sys/fs/selinux/policy || abort "Missing stock security type: $type"
done
if [ -e "/system_ext/bin/mosey_server" ]; then
  [ "$(sha256sum "/system_ext/bin/mosey_server" | cut -d " " -f 1)" = "97729c366d09fd34ac9402a2c2cd350f8a78cd060368344753d55cefea225c1c" ] || abort "Existing component differs: bin/mosey_server"
fi
if [ -e "/system_ext/lib64/libmosey_daemon_ffi.so" ]; then
  [ "$(sha256sum "/system_ext/lib64/libmosey_daemon_ffi.so" | cut -d " " -f 1)" = "ec8f58c686046788bacb628793c83c28f7659e524cf23afaf5511bf32af5447a" ] || abort "Existing component differs: lib64/libmosey_daemon_ffi.so"
fi
if [ -e "/system_ext/priv-app/MoseyApp/MoseyApp.apk" ]; then
  [ "$(sha256sum "/system_ext/priv-app/MoseyApp/MoseyApp.apk" | cut -d " " -f 1)" = "e2d559965d1dbf2dbc892adc4f5181c859334a9063321e6c18e9141cdddc3aae" ] || abort "Existing component differs: priv-app/MoseyApp/MoseyApp.apk"
fi
if [ -e "/system_ext/etc/permissions/privapp-permissions-com.google.android.mosey.xml" ]; then
  [ "$(sha256sum "/system_ext/etc/permissions/privapp-permissions-com.google.android.mosey.xml" | cut -d " " -f 1)" = "80dcb7b3d55438547a96de787d797b6f7674a6aa42126c4d2e6cd413d3e93294" ] || abort "Existing component differs: permissions/privapp-permissions-com.google.android.mosey.xml"
fi
if [ -e "/system/etc/default-permissions/default-permissions-com.google.android.mosey.xml" ]; then
  [ "$(sha256sum "/system/etc/default-permissions/default-permissions-com.google.android.mosey.xml" | cut -d " " -f 1)" = "19d7d6461a3aeb1348b5a3b8d54f02c7f6244e761b7790c4aa60cc95822b608c" ] || abort "Existing component differs: default-permissions/default-permissions-com.google.android.mosey.xml"
fi
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
set_perm "$MODPATH/system/system_ext/bin/mosey_server" 0 0 0755 u:object_r:mosey_server_exec:s0
set_perm "$MODPATH/controller" 0 0 0755
ui_print 'Official components staged through standard ROOT module system merging. Reboot required.'
