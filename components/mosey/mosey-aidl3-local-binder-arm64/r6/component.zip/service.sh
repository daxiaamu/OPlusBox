#!/system/bin/sh
set -eu
MODDIR=${0%/*}
setprop sys.obx.mosey_backend_ready failed
setprop persist.sys.obx.mosey_allow 0
setprop sys.obx.mosey_session ''
sha256sum -c "$MODDIR/mounted-checksums.txt" || exit 1
setprop sys.obx.mosey_backend_ready local-v1
