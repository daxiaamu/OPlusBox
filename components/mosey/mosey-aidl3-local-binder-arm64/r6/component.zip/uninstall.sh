#!/system/bin/sh
MODDIR=${0%/*}
setprop persist.sys.obx.mosey_allow 0
setprop sys.obx.mosey_session ''
"$MODDIR/controller" stop
