#!/system/bin/sh
# ColorOS only. Regenerate from this boot's original file, before SystemConfig loads.
set -eu
setprop sys.obx.coloros_gms_stage failed
target=/my_product/etc/permissions/oplus_google_cn_gms_features.xml
base=/metadata/obx_coloros_google_features
test ! -L "$base"
mkdir -p "$base"
chmod 0700 "$base"
original="$base/original"
test ! -L "$original"
mkdir -p "$original"
# A non-recursive bind of the parent excludes another module's file bind mount.
mount -o bind /my_product "$original"
mounted=1
cleanup() {
    if [ "$mounted" = 1 ]; then umount "$original"; fi
    rm -f "$base/features.tmp"
}
trap cleanup EXIT
source="$original/etc/permissions/oplus_google_cn_gms_features.xml"
if [ ! -e "$source" ]; then
    setprop sys.obx.coloros_gms_stage ready
    exit 0
fi
test -f "$source"
test ! -L "$source"
test ! -L "$base/features.tmp"
test ! -L "$base/features.xml"
# Only drop the standalone CN feature declaration. Keep all other lines verbatim.
# If a future XML changes its syntax, fail without masking the original file.
sed '/^[[:space:]]*<feature[[:space:]][[:space:]]*name="cn\.google\.services"[[:space:]]*\/[[:space:]]*>[[:space:]]*$/d' "$source" > "$base/features.tmp"
if grep -q 'cn\.google\.services' "$base/features.tmp"; then exit 1; fi
chmod 0644 "$base/features.tmp"
chown 0:0 "$base/features.tmp"
chcon u:object_r:system_file:s0 "$base/features.tmp"
mv -f "$base/features.tmp" "$base/features.xml"
umount "$original"
mounted=0
mount -o ro,bind "$base/features.xml" "$target"
setprop sys.obx.coloros_gms_stage ready
