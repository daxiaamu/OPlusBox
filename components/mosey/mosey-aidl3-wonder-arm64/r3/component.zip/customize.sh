#!/system/bin/sh
# Sourced by the ROOT installer. Never replace firmware directories with snapshots.
[ "$(getprop ro.build.version.sdk)" -ge 36 ] || abort 'Android 16 or newer required'
getprop ro.product.cpu.abilist | grep -q arm64-v8a || abort 'ARM64 required'
grep -qw overlay /proc/filesystems || abort 'Overlay filesystem unavailable'
for type in mosey_app mosey_server mosey_server_exec; do
  grep -aq "$type" /sys/fs/selinux/policy || abort "Missing system security type: $type"
done
test -d /system_ext/bin || abort "Missing system directory"
test -d /system_ext/lib64 || abort "Missing system directory"
test -d /system_ext/priv-app || abort "Missing system directory"
test -d /system_ext/etc/vintf/manifest || abort "Missing system directory"
test -d /system_ext/etc/permissions || abort "Missing system directory"
test -d /system/etc/default-permissions || abort "Missing system directory"
if [ -e "/system_ext/bin/mosey_server" ]; then
  [ "$(sha256sum "/system_ext/bin/mosey_server" | cut -d " " -f 1)" = "97729c366d09fd34ac9402a2c2cd350f8a78cd060368344753d55cefea225c1c" ] || abort "Existing component differs: bin/mosey_server"
fi
if [ -e "/system_ext/lib64/libmosey_daemon_ffi.so" ]; then
  [ "$(sha256sum "/system_ext/lib64/libmosey_daemon_ffi.so" | cut -d " " -f 1)" = "ec8f58c686046788bacb628793c83c28f7659e524cf23afaf5511bf32af5447a" ] || abort "Existing component differs: lib64/libmosey_daemon_ffi.so"
fi
if [ -e "/system_ext/priv-app/MoseyApp/MoseyApp.apk" ]; then
  [ "$(sha256sum "/system_ext/priv-app/MoseyApp/MoseyApp.apk" | cut -d " " -f 1)" = "e2d559965d1dbf2dbc892adc4f5181c859334a9063321e6c18e9141cdddc3aae" ] || abort "Existing component differs: priv-app/MoseyApp/MoseyApp.apk"
fi
if [ -e "/system_ext/etc/vintf/manifest/manifest_mosey.xml" ]; then
  [ "$(sha256sum "/system_ext/etc/vintf/manifest/manifest_mosey.xml" | cut -d " " -f 1)" = "64d186e23527c993c1ba2dd973128ca3834e8649e51d28d9a197fc663255d50f" ] || abort "Existing component differs: vintf/manifest_mosey.xml"
fi
if [ -e "/system_ext/etc/permissions/privapp-permissions-com.google.android.mosey.xml" ]; then
  [ "$(sha256sum "/system_ext/etc/permissions/privapp-permissions-com.google.android.mosey.xml" | cut -d " " -f 1)" = "80dcb7b3d55438547a96de787d797b6f7674a6aa42126c4d2e6cd413d3e93294" ] || abort "Existing component differs: permissions/privapp-permissions-com.google.android.mosey.xml"
fi
if [ -e "/system/etc/default-permissions/default-permissions-com.google.android.mosey.xml" ]; then
  [ "$(sha256sum "/system/etc/default-permissions/default-permissions-com.google.android.mosey.xml" | cut -d " " -f 1)" = "19d7d6461a3aeb1348b5a3b8d54f02c7f6244e761b7790c4aa60cc95822b608c" ] || abort "Existing component differs: default-permissions/default-permissions-com.google.android.mosey.xml"
fi
(cd "$MODPATH/payload" && sha256sum -c "$MODPATH/payload-checksums.txt") || abort 'Payload verification failed'
DEST=/metadata/obx_mosey_components_r3
if [ -e "$DEST" ]; then
  [ -d "$DEST" ] && [ ! -L "$DEST" ] || abort 'Unexpected backing destination'
else
  STAGE="$MODPATH/backing-stage"
  mkdir "$STAGE" || abort 'Cannot create payload staging'
  cp -a "$MODPATH/payload/." "$STAGE/" || abort 'Cannot stage components'
  (cd "$STAGE" && sha256sum -c "$MODPATH/payload-checksums.txt") || abort 'Staged payload differs'
  mv "$STAGE" "$DEST" || abort 'Cannot commit component backing'
fi
[ "$(find "$DEST" -type l | wc -l)" -eq 0 ] || abort 'Unexpected payload symlink'
[ "$(find "$DEST" -type f | wc -l)" -eq 6 ] || abort 'Unexpected payload files'
(cd "$DEST" && sha256sum -c "$MODPATH/payload-checksums.txt") || abort 'Backing payload differs'
chown -R 0:0 "$DEST" || abort 'Component ownership failed'
find "$DEST" -type d -exec chmod 0755 {} \; || abort 'Directory modes failed'
find "$DEST" -type f -exec chmod 0644 {} \; || abort 'File modes failed'
chmod 0755 "$DEST/bin/mosey_server" || abort 'Server mode failed'
chcon -R u:object_r:system_file:s0 "$DEST" || abort 'Component labels failed'
chcon u:object_r:mosey_server_exec:s0 "$DEST/bin/mosey_server" || abort 'Server label failed'
# An earlier owned module's service disappears on upgrade; carry its definition forward.
if [ -z "$(getprop init.svc.mosey_server)" ] || [ -d /data/adb/modules/oplusbox_mosey_native_stage ]; then
  cat "$MODPATH/mosey-service.rc" >> "$MODPATH/initrc/20-native.rc"
fi
ui_print 'Official components staged. Existing system files remain visible. Reboot required.'
